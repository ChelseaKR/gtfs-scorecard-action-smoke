This archive is a test fixture for ChelseaKR/gtfs-scorecard-action-smoke.

It is a well-formed zip that is not a GTFS Schedule feed: it contains no
agency.txt, no stops.txt, no routes.txt, no trips.txt and no stop_times.txt.

The `unscorable-feed` job hands it to the GTFS Scorecard action to prove the
action refuses a feed it cannot read, rather than publishing a plausible
looking grade for one. Do not "fix" this file by adding GTFS data to it; that
would delete the assertion.
